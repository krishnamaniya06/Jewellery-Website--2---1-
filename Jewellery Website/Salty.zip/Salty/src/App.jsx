import Navbar from "./Components/Navbar";


function App() {
  return (
    <div>
      <Navbar />
      <h1 className="mt-20 text-center"></h1>
    </div>
  );
}

export default App;

